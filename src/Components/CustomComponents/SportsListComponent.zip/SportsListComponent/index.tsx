import SportsListComponent from "./SportsList";

export default SportsListComponent