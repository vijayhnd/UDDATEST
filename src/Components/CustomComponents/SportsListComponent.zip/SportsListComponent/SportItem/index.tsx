import SportsItemView from "./SportsItem";

export default SportsItemView