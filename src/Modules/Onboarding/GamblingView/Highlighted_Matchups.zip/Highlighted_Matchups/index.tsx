import G_Highlighted_Matchups_View from "./Highlighted_Matchups_View";

export default G_Highlighted_Matchups_View;