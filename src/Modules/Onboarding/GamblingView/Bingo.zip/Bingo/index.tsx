import G_CreateSquareView from "./createsquare";

export default G_CreateSquareView;