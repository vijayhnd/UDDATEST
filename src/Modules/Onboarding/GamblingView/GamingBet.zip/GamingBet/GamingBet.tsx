import React, { ReactInstance } from "react";
import { View, Text, Image, ScrollView, FlatList, Animated, TouchableWithoutFeedback, Share, TouchableOpacity } from "react-native";
import styles from './styles';
import Container from '../../../../Components/Container';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import AppValidationComponent, { Field, AppValidationComponentState, AppValidationComponentProps } from "../../../../Util/AppValidationComponent";
import { ISubheaderListener } from "../../../../Components/CustomComponents/SubHeader/SubHeader";
import { MenuIconListener } from "../../../../Components/Icons/MenuIcon/MenuIcon";
import { LogoIconListener } from "../../../../Components/Icons/LogoIcon/LogoIcon";
import RouterBuilder from "../../../../Router";
import AppScreens from "../../../../Util/AppScreens";
import Application from "../../.../../../../Entities/Application";
import ProgressLoader from 'rn-progress-loader';
import Popover from 'react-native-popover-view'
import moment from 'moment';
import LogoutUtill from "../../../../Util/LogoutUtill";
import UrlService from '../../../../Services/Core/ServiceURI'
import ReferralService from "../../../../Services/Referral/ReferralService";

var update = require('immutability-helper');

const ProfilePageContent = {
    key: 'somethun',
    page_title: 'OPEN PLAYS',
}

interface G_GamingBetViewProps extends AppValidationComponentProps {
}

interface G_GamingBetViewState extends AppValidationComponentState {
    DataList?: any;
    isshow: any;
    loader: any;
    OpenPlaySwitchAccepted: any;
    contentoftoggle: any;
    people_list: any;
    selected_bet: any;
    blackdialogDate: any;
}


const bottom_initial = 0;
export default class G_GamingBetView extends AppValidationComponent<G_GamingBetViewProps, G_GamingBetViewState>
    implements MenuIconListener, ISubheaderListener, LogoIconListener {
    private authorisationToken = Application.sharedApplication().user!.authenticationToken;
    private my_referral_code = Application.sharedApplication().user!.profile.my_referral_code;
    private referralservice = new ReferralService();
    constructor(props: G_GamingBetViewProps) {
        super(props);
        this.state = {
            DataList: [],
            isshow: true,
            loader: false,
            OpenPlaySwitchAccepted: '',
            contentoftoggle: 'Show Private',
            people_list: '',
            selected_bet: '',
            blackdialogDate: ''
        };
    }

    componentDidMount() {
        this.callMethod('1');
    }

    // ----------------------------------------------- API calling ---------------------------------------


    callMethod(OpenPlayVersion: any) {

        this.setState({ loader: true });
        var url;
        if (OpenPlayVersion == 1) {
            url = UrlService.CONSTURI +'index.php/v1/apiGaming/open_plays/' + OpenPlayVersion;
        }
        else {
            url = UrlService.CONSTURI +'index.php/v1/apiGaming/open_plays/' + OpenPlayVersion;
        }

        fetch(url, {
            method: 'GET',
            headers: {
                'authorisation': this.authorisationToken
            },
        }).then((response) => response.json())
            .then((responseJson) => {
                this.setState({ loader: false });
                this.setState({ DataList: responseJson.data });
                console.log('Success openplay' + JSON.stringify(this.state.DataList));
                if (responseJson.message == "Access Expired.") {
                    // AlertUtil.show("Session Expired ! Please login again");
                    console.log("Footer comp ---->"+responseJson.message);
                    LogoutUtill.logoutButtonPressed(this.props);
                   }
            })
            .catch(error => {
                this.setState({ loader: false });
                console.log(error);
            })
    }


    // ----------------------------------------------- Methods ---------------------------------------

    accountNameTapped() {
        this.props.navigation!.navigate(AppScreens.G_ProfileView);
    }

    iconDidTapped() {
        this.props.navigation!.navigate(AppScreens.G_Settings_2_View);
    }

    LogoiconDidTapped() {
        RouterBuilder.replaceRouteTo(AppScreens.G_DashboardView, this.props)
    }

    availableBalanceTapped() {
    }

    openPlaysTapped() {
        RouterBuilder.replaceRouteTo(AppScreens.G_UddaContests, this.props)
    }

    coveredPlaysTapped() {
    }

    cellDidClicked(tag: number, tableViewCellReference: ReactInstance): void {
    }

    OpenPlaySwitchValueChanged() {

        if (this.state.OpenPlaySwitchAccepted === true) {
            this.setState({ OpenPlaySwitchAccepted: false });
            this.callMethod('1');
        }
        else {
            this.setState({ OpenPlaySwitchAccepted: true });
            this.callMethod('2');
        }
    }

    async shareOption(item: any) {
        var MessageString: any;
        var oddsString: any;
        var teamName: any;
        var teamName2: any;
        var url: any;
        var amount: any;
        var referStr: any;
        if (item.ttype == 'o') {
            if (item.bet_odds_type == 'ML') {
                oddsString = "Money Line";
            }
            else if (item.bet_odds_type == 'T') {
                oddsString = "Total";
            }
            else {
                oddsString = "Spread";
            }

           /*  if (item.home.is_bet_team == 'true') {
                teamName = item.home.home_team_name
                teamName2 = item.away.away_team_name
            } else {
                teamName = item.away.away_team_name
                teamName2 = item.home.home_team_name
            }


            url = "http://bet.udda.com/index.php?t=oddsbet&i=" + item.encryptor_bet_id;

            MessageString = "I just bet " + item.amount + " UDDA Bucks on the " +
                oddsString + " " + amount + " for the team " + teamName + "V/s" + teamName2 + ". " + url; */

        // @vijay code 

            if (item.home.is_bet_team == 'true') {
                teamName = item.home.home_team_name;
                teamName2 = item.away.away_team_name;
                amount = item.home.ml_home_price;
            } else {
                teamName = item.away.away_team_name;
                teamName2 = item.home.home_team_name;
                amount = item.away.ml_away_price;
            }


            url = "http://bet.udda.com/index.php?t=oddsbet&i=" + item.encryptor_bet_id;
            url = await this.referralservice.getReferralUrl(url, this.my_referral_code, "U"); // Getting Dynamic Share Link From Firebase
            referStr = "\n Use Referral Code " + this.my_referral_code + " to sign up. ";

            MessageString = "I just bet " + item.amount + " UDDA Bucks on the " +
                oddsString + " " + amount + " for the team " + teamName + "V/s" + teamName2 + "." + referStr + "\n" + url;

        }
        else {

            url = "http://bet.udda.com/index.php?t=propsbet&i=" + item.encryptor_bet_id;
            url = await this.referralservice.getReferralUrl(url, this.my_referral_code, "U"); // Getting Dynamic Share Link From Firebase
            referStr = "\n Use Referral Code " + this.my_referral_code + " to sign up. ";

            MessageString = " I just bet a " + item.amount + " UDDA Bucks that " + item.question + " is " + item.bet_team_type + item.total + item.line + " bet on this. Would you accept the Bet? " + referStr + "\n" + url;

        }

        console.log('private url ' + JSON.stringify(MessageString));
        Share.share({
            message: MessageString,
        })
            .then(result => {
                console.log(result)
                this.closePopover();
            })
            .catch(errorMsg => {
                console.log(errorMsg)
                this.closePopover();

            });
    }

    gotoDashboard() {
        RouterBuilder.replaceRouteTo(AppScreens.G_DashboardView, this.props)
    }
    gotoBetHistory() {
        RouterBuilder.replaceRouteTo(AppScreens.G_HistoryView, this.props)

    }



    blackdialogOpen(item: any, index: any, index2: any, index3: any) {
        var new_time_stamp = item.bet_time_stamp * 1000;
        var formated_time = moment(new_time_stamp).format('MMMM DD,YYYY');
        this.setState({ blackdialogDate: formated_time });


        for (let i = 0; i < this.state.DataList.length; i++) {
            for (let j = 0; j < this.state.DataList[i].game_array.length; j++) {
                for (let k = 0; k < this.state.DataList[i].game_array[j].game_array.length; k++) {
                    if (i == index && j == index2 && k == index3) {
                        this.state.DataList[i].game_array[j].game_array[k].BlackDialog = true
                        this.setState({ people_list: this.state.DataList[i].game_array[j].game_array[k].share_info });
                        this.setState({ selected_bet: item });
                    }
                    else {
                        this.state.DataList[i].game_array[j].game_array[k].BlackDialog = false

                    }
                }
            }
        }
        this.setState({ DataList: this.state.DataList });
    }



    closePopover() {
        for (let i = 0; i < this.state.DataList.length; i++) {
            for (let j = 0; j < this.state.DataList[i].game_array.length; j++) {
                for (let k = 0; k < this.state.DataList[i].game_array[j].game_array.length; k++) {
                    this.state.DataList[i].game_array[j].game_array[k].BlackDialog = false
                }
            }
        }
        this.setState({ DataList: this.state.DataList });
    }




    getblackDialog(touchableRef: any) {
        return (

            // <Popover style={{ position: "absolute", top: 0, right: 15, zIndex: 100, width: '70%'}}>

            <Popover
                isVisible={true}
                fromView={touchableRef}
                onRequestClose={() => this.closePopover()}>

                <View style={{ borderRadius: 5, backgroundColor: '#fff', padding: 10, width: '100%', maxHeight: 250, }}>

                    <TouchableWithoutFeedback onPress={() => { this.closePopover() }} >
                        <View>
                            <Image source={require('../../../../images/close.png')} style={{ height: 10, width: 10, alignSelf: 'flex-end', marginRight: 2, marginVertical: 5, marginBottom: 8 }}></Image>
                        </View>
                    </TouchableWithoutFeedback>


                    <View style={{ width: '100%', flexDirection: 'row' }}>
                        <Text style={{ width: '40%', fontSize: 12, fontFamily: 'Montserrat-Regular', height: 20, alignItems: 'center' }}>Bet Date:</Text>

                        <View style={{ flexDirection: 'row', width: '60%', justifyContent: 'flex-end', height: 20 }}>
                            <Text style={{ fontFamily: 'Montserrat-Bold', fontSize: 12, alignItems: 'center' }}>{this.state.blackdialogDate}</Text>
                        </View>
                    </View>

                    <View style={{ width: '100%', flexDirection: 'row' }}>
                        <Text style={{ width: '40%', fontSize: 12, fontFamily: 'Montserrat-Regular', height: 20, alignItems: 'center' }}>Creator</Text>

                        <View style={{ flexDirection: 'row', width: '60%', justifyContent: 'flex-end', height: 20 }}>
                            <Text style={{ fontFamily: 'Montserrat-Bold', fontSize: 12, alignItems: 'center' }}>{this.state.selected_bet.creator}</Text>
                        </View>
                    </View>

                    <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                        <View style={{ backgroundColor: '#777777', marginVertical: 5, width: '95%', height: 2, alignItems: 'center' }}>
                        </View>
                    </View>

                    {this.state.people_list.length > 0 ?
                        <FlatList
                            extraData={this.state}
                            data={this.state.people_list}
                            keyExtractor={(item: any, index) => index.toString()}
                            bounces={false}
                            renderItem={({ item, index }: any) => {
                                return (
                                    item.status == 1 ? <View>
                                        <View style={{ width: '100%', flexDirection: 'row' }}>
                                            <Text style={{ width: '70%', fontSize: 12, fontFamily: 'Montserrat-Bold', height: 20, alignItems: 'center' }}>{item.username}</Text>

                                            <View style={{ flexDirection: 'row', width: '30%', justifyContent: 'flex-end', height: 20 }}>
                                                <Image source={require('../../../../images/BucksWhite.png')} style={{ height: 8, width: 8, alignItems: 'center', marginRight: 2, marginTop: 3 }} />
                                                <Text style={{ fontFamily: 'Montserrat-Bold', fontSize: 12, alignItems: 'center' }}>{item.amount}</Text>
                                            </View>
                                        </View>
                                    </View> : <View >
                                            <View style={{ width: '100%', flexDirection: 'row' }}>
                                                <Text style={{ width: '70%', color: '#808080', fontSize: 12, fontFamily: 'Montserrat-Bold', height: 20, alignItems: 'center', textDecorationLine: 'line-through' }}>{item.username}</Text>

                                                <View style={{ flexDirection: 'row', width: '30%', justifyContent: 'flex-end', height: 20 }}>
                                                    <Image source={require('../../../../images/BucksWhite.png')} style={{ height: 8, width: 8, alignItems: 'center', marginRight: 2, marginTop: 3 }} />
                                                    <Text style={{ color: '#808080', fontFamily: 'Montserrat-Bold', fontSize: 12, alignItems: 'center', textDecorationLine: 'line-through' }}>{item.amount}</Text>
                                                </View>
                                            </View>
                                        </View>
                                )
                            }}
                        />
                        :
                        <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                            <Text style={{ width: '100%', fontSize: 12, fontFamily: 'Montserrat-Bold', height: 20, textAlign: 'center' }}>No record found</Text>
                        </View>

                    }

                    <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                        <TouchableWithoutFeedback onPress={() => { this.shareOption(this.state.selected_bet) }}>
                            <View style={{ backgroundColor: '#68bcbc', paddingVertical: 5, marginVertical: 10, width: '95%', alignItems: 'center', borderRadius: 3 }}>
                                <Text style={{ color: 'white', fontFamily: 'Montserrat-Bold', fontSize: 12, alignItems: 'center' }}> Invite More Friends</Text>
                            </View>
                        </TouchableWithoutFeedback>
                    </View>

                </View>
            </Popover>

        )
    }


    // -----------------------------------------------Design and Design Methods---------------------------------------

    render() {
        return (
            <Container
                title={ProfilePageContent.page_title}
                isHeader={true}
                isSubHeader={true}
                isTitle={false}
                showIndicator={false}
                menuIconListener={this}
                LogoIconListener={this}
                isSetting={false}
                accountNameListener={this}
                availableBalanceListener={this}
                coveredPlaysListener={this}
                openPlaysListener={this} >

                <View style={styles.scrollContent} >
                    <View style={styles.mainContent}>
                        <ProgressLoader
                            visible={this.state.loader}
                            isModal={true} isHUD={true}
                            hudColor={"#68bcbc"}
                            color={"#FFFFFF"} />

                        <View style={{ flex: 1 }}>
                            <View style={{ flexShrink: 1, backgroundColor: 'white', height: '90%' }}>



                                <View style={styles.NameHeaderContainer}>
                                    <View style={{ width: '60%' }}>
                                        <Text style={styles.NameStyle}>YOUR BETS</Text>
                                    </View>
                                    <View style={{ width: '40%', alignItems: 'center', flexDirection: 'row', }}>

                                        <View style={{ width: 'auto', height: 'auto', }}>
                                            <Text style={{ fontSize: hp(1.5), fontFamily: 'Montserrat-SemiBold', marginLeft: 5, marginRight: 2, color: this.state.OpenPlaySwitchAccepted == false ? 'black' : '#888888', textAlign: 'right' }}>Public</Text>
                                            <Text style={{ fontSize: hp(1.5), fontFamily: 'Montserrat-SemiBold', marginLeft: 5, marginRight: 2, color: this.state.OpenPlaySwitchAccepted == false ? 'black' : '#888888', textAlign: 'right' }}>Bets</Text>
                                        </View>

                                        <TouchableWithoutFeedback onPress={() => { this.OpenPlaySwitchValueChanged() }}>
                                            <Image source={this.state.OpenPlaySwitchAccepted == true ? require('../../../../images/toggle_on_G.png') : require('../../../../images/toggle_off.png')}
                                                style={{ height: 20, width: 40 }}
                                                resizeMode="contain"></Image>
                                        </TouchableWithoutFeedback>


                                        <View style={{ width: 'auto', height: 'auto', }}>
                                            <Text style={{ fontSize: hp(1.5), fontFamily: 'Montserrat-SemiBold', marginLeft: 5, marginRight: 2, color: this.state.OpenPlaySwitchAccepted == true ? 'black' : '#888888', textAlign: 'left' }}>Private</Text>
                                            <Text style={{ fontSize: hp(1.5), fontFamily: 'Montserrat-SemiBold', marginLeft: 5, marginRight: 2, color: this.state.OpenPlaySwitchAccepted == true ? 'black' : '#888888', textAlign: 'left' }}>Bets</Text>
                                        </View>

                                    </View>



                                </View>

                                <View style={[styles.titleContainer]} >
                                    <View style={{ width: '100%', height: 35, backgroundColor: '#666666', flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>

                                        <View style={{ width: '38%', height: '100%', justifyContent: 'center' }}>
                                            <Text style={{ color: 'white', fontSize: hp(1.4), fontFamily: 'Montserrat-Bold', textAlign: 'center' }}>
                                                MATCH UP
                                            </Text>
                                        </View>
                                        <View style={{ width: '16%', height: '100%', justifyContent: 'center' }}>
                                            <Text style={{ color: 'white', fontSize: hp(1.4), textAlign: 'center', fontFamily: 'Montserrat-Bold' }}>
                                                AMOUNT {"\n"} BET
                                            </Text>
                                        </View>
                                        <View style={{ width: '22%', height: '100%', justifyContent: 'center' }}>
                                            <Text style={{ color: 'white', fontSize: hp(1.4), textAlign: 'center', fontFamily: 'Montserrat-Bold', }}>
                                                LINE
                                            </Text>
                                        </View>
                                        <View style={{ width: '24%', height: '100%', justifyContent: 'center' }}>
                                            <Text style={{ color: 'white', fontSize: hp(1.4), textAlign: 'center', fontFamily: 'Montserrat-Bold', }}>
                                                AMOUNT TO {"\n"} WIN
                                            </Text>
                                        </View>
                                    </View>
                                </View>

                                {this.state.DataList.length > 0 ?
                                    <FlatList
                                        data={this.state.DataList}
                                        extraData={this.state}
                                        keyExtractor={(item: any, index) => index.toString()}
                                        bounces={false}
                                        renderItem={({ item, index }: any) => {
                                            var data_index = index;
                                            var index2 = index;

                                            return (

                                                <View style={{ backgroundColor: 'white' }}>

                                                    {/* --------------------- Game Header ---------------- */}
                                                    <View style={styles.gameheader}>
                                                        <View style={{ width: '90%', flexDirection: 'row', }}>
                                                            <View>
                                                                <Text style={styles.gameheadertext} >
                                                                    {item.date_label}
                                                                </Text>
                                                            </View>
                                                        </View>

                                                        <View style={{ width: '10%' }}>
                                                            <Text style={styles.gamecounttext}>( {item.bet_count} )</Text>
                                                        </View>
                                                    </View>

                                                    {/* --------------------- Games Arrray ---------------- */}
                                                    <FlatList
                                                        data={item.game_array}
                                                        extraData={this.state}
                                                        keyExtractor={(item: any, index) => index.toString()}
                                                        renderItem={({ item, index }: any) => {

                                                            var Sport_league = item.league_id;

                                                            return (
                                                                <View>
                                                                    <View style={[styles.gamedatetimecontainer, { flexDirection: 'row' }]}>

                                                                        <View style={{ paddingLeft: 5, paddingRight: 10, justifyContent: "center" }}>
                                                                            <Image source={{ uri: item.sport_icon }} style={{ height: 15, width: 15 }}></Image>
                                                                        </View>

                                                                        <Text style={styles.datetext} >
                                                                            {item.sport_name}

                                                                        </Text>
                                                                    </View>

                                                                    {/* --------------------- dates Arrray and beted matches row ---------------- */}
                                                                    <FlatList
                                                                        data={item.game_array}
                                                                        extraData={this.state}
                                                                        keyExtractor={(item: any, index) => index.toString()}
                                                                        renderItem={({ item, index }: any) => {
                                                                            var date_array_index = index;
                                                                            var sign_spread_home: any;
                                                                            var sign_spread_away: any;
                                                                            var index3 = index;

                                                                            if (item.bet_odds_type == 'PS') {
                                                                                sign_spread_home = item.home.ps_home_spread.split(' ');
                                                                                sign_spread_away = item.away.ps_away_spread.split(' ');
                                                                            }
                                                                            return (
                                                                                <View>
                                                                                    <View style={styles.gamelistcontainer}>
                                                                                        <TouchableWithoutFeedback>
                                                                                            <View style={styles.gamelistindexcontainer}>
                                                                                                <Text style={[styles.indextext]}> {item.data_index + 1} </Text>
                                                                                            </View>
                                                                                        </TouchableWithoutFeedback>

                                                                                        {item.ttype == 'o' ?
                                                                                            <View style={styles.gamelistteamcontainer}>

                                                                                                <View style={styles.gamelistteam1container}>

                                                                                                    <View style={styles.gamelistmatchup}>
                                                                                                        <Text style={[styles.teamtitletext, { color: item.away.is_bet_team == 'true' ? '#68bcbc' : '#888888' }]}> {Sport_league == '2' || Sport_league == '4' ? item.away.t : item.away.t} </Text>
                                                                                                    </View>


                                                                                                    <View style={item.away.is_bet_team == 'true' ? styles.gamelistamountbet : styles.gamelistamountbetteam2}>
                                                                                                        {item.away.is_bet_team == 'true' ? <Image source={require('../../../../images/White_Bucks.png')} style={{ height: 8, width: 8, marginRight: 3 }} /> : null}
                                                                                                        <Text style={item.away.is_bet_team == 'true' ? styles.teamoddstext : styles.team2oddstext}>{item.away.is_bet_team == 'true' ? parseInt(item.amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : null}</Text>
                                                                                                    </View>

                                                                                                    <View style={item.away.is_bet_team == 'true' ? styles.gamelistline : styles.gamelistlineteam2}>

                                                                                                        {item.bet_odds_type == 'ML' ?
                                                                                                            <Text style={item.away.is_bet_team == 'true' ? styles.teamoddstext : styles.team2oddstext}>{(item.away.ml_away_price > 0 ? '+' : item.away.ml_away_price == 0 ? '' : '-') + Math.abs(item.away.ml_away_price)} </Text>
                                                                                                            :
                                                                                                            item.bet_odds_type == 'T' ?
                                                                                                                <Text style={item.away.is_bet_team == 'true' ? styles.teamoddstext : styles.team2oddstext}>{item.away.total}</Text>
                                                                                                                :
                                                                                                                <Text style={item.away.is_bet_team == 'true' ? styles.teamoddstext : styles.team2oddstext}>{(sign_spread_away[0] > 0 ? '+' : '') + item.away.ps_away_spread}</Text>
                                                                                                        }

                                                                                                    </View>

                                                                                                </View>

                                                                                                <View style={styles.gamelistteam2container}>

                                                                                                    <View style={styles.gamelistmatchupteam2}>
                                                                                                        <Text style={[styles.team2titletext, { color: item.home.is_bet_team == 'true' ? '#68bcbc' : '#888888' }]}> {Sport_league == '2' || Sport_league == '4' ? item.home.t : item.home.t} </Text>
                                                                                                    </View>

                                                                                                    <View style={item.home.is_bet_team == 'true' ? styles.gamelistamountbet : styles.gamelistamountbetteam2}>
                                                                                                        {item.home.is_bet_team == 'true' ? <Image source={require('../../../../images/White_Bucks.png')} style={{ height: 8, width: 8, marginRight: 3 }} /> : null}
                                                                                                        <Text style={item.home.is_bet_team == 'true' ? styles.teamoddstext : styles.team2oddstext}>{item.home.is_bet_team == 'true' ? parseInt(item.amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : null}</Text>
                                                                                                    </View>

                                                                                                    <View style={item.home.is_bet_team == 'true' ? styles.gamelistline : styles.gamelistlineteam2}>

                                                                                                        {item.bet_odds_type == 'ML' ?
                                                                                                            <Text style={item.home.is_bet_team == 'true' ? styles.teamoddstext : styles.team2oddstext}>{(item.home.ml_home_price > 0 ? '+' : item.home.ml_home_price == 0 ? '' : '-') + Math.abs(item.home.ml_home_price)}</Text>
                                                                                                            :
                                                                                                            item.bet_odds_type == 'T' ?
                                                                                                                <Text style={item.home.is_bet_team == 'true' ? styles.teamoddstext : styles.team2oddstext}>{item.home.total} </Text>
                                                                                                                :
                                                                                                                <Text style={item.home.is_bet_team == 'true' ? styles.teamoddstext : styles.team2oddstext}>{(sign_spread_home[0] > 0 ? '+' : '') + item.home.ps_home_spread} </Text>
                                                                                                        }

                                                                                                    </View>

                                                                                                </View>

                                                                                            </View>
                                                                                            :
                                                                                            <View style={styles.gamelistteamcontainer}>

                                                                                                <View style={[styles.QuestionContainer]}>
                                                                                                    <Text style={styles.Quetitletext}> {item.question} </Text>
                                                                                                </View>

                                                                                                <View style={styles.gamelistteam2container}>

                                                                                                    <View style={[styles.gamelistmatchupteam2, { backgroundColor: '#888888' }]}>
                                                                                                        <Text style={styles.Proptitletext}> {item.ttype == 'p' ? 'PROP BET' : 'CUSTOM BET'} </Text>
                                                                                                    </View>

                                                                                                    <View style={styles.gamelistamountbet}>
                                                                                                        <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                                                                                                            <Image source={require('../../../../images/White_Bucks.png')} style={{ height: 10, width: 10, marginRight: 3 }} />
                                                                                                            <Text style={styles.teamoddstext}>{parseInt(item.amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")} </Text>
                                                                                                        </View>
                                                                                                    </View>

                                                                                                    <View style={styles.gamelistline}>
                                                                                                        {item.ttype == 'p' ?
                                                                                                            <Text style={styles.teamoddstext}> {item.bet_team_type == 'under' ? 'U' : 'O'} {item.total}<Text style={{ fontFamily: 'Montserrat-SemiBold' }}> ({item.line})</Text> </Text>
                                                                                                            :
                                                                                                            <Text style={styles.teamoddstext}> {item.line} <Text style={{ fontFamily: 'Montserrat-SemiBold' }}>ML </Text> </Text>
                                                                                                        }
                                                                                                    </View>

                                                                                                </View>

                                                                                            </View>
                                                                                        }



                                                                                        <View style={styles.gamelisttotalcontainer}>
                                                                                            <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                                                                                                <Image source={require('../../../../images/White_Bucks.png')} style={{ height: 10, width: 10, marginRight: 3 }} />
                                                                                                <Text style={styles.teamtotaltext}>{parseInt(item.amount_to_win).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")} </Text>
                                                                                            </View>
                                                                                            {item.bet_type == 2 ?
                                                                                                <View style={{ marginRight: 2 }}>
                                                                                                    <TouchableWithoutFeedback onPress={() => { this.blackdialogOpen(item, data_index, index2, index3) }}>
                                                                                                        <Image ref={ref => item.touchable = ref} source={require('../../../../images/Bet_Share.png')} style={{ height: 15, width: 15 }} resizeMode='contain' />
                                                                                                    </TouchableWithoutFeedback>
                                                                                                </View>
                                                                                                : null
                                                                                            }
                                                                                        </View>
                                                                                        {item.BlackDialog == true ? this.getblackDialog(item.touchable) : null}
                                                                                    </View>
                                                                                </View>
                                                                            )
                                                                        }} />
                                                                </View>
                                                            )
                                                        }} />
                                                </View>
                                            )
                                        }} />
                                    :
                                    <View style={styles.OtherTextContainer}>
                                        <View style={styles.OtherTextSubContainer}>
                                            <Text style={styles.UnderConstText}>You haven't placed</Text>
                                            <Text style={styles.UnderConstText}>a bet yet.</Text>
                                            <Text style={[styles.DescText, { marginTop: 15 }]}>Go to your favourite sport/team </Text>
                                            <Text style={styles.DescText}>to start betting. </Text>
                                        </View>
                                    </View>
                                }

                            </View>

                            <View style={{ height: '10%', justifyContent: 'center', alignItems: 'center', width: '100%', backgroundColor: 'white' }}>
                                <TouchableOpacity onPress={() => { this.gotoBetHistory() }}>
                                    <Text style={{ color: '#f26522', fontSize: hp(1.9), fontFamily: 'Montserrat-Bold', textAlign: 'center', textDecorationLine: 'underline' }}>BET HISTORY</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </View>
            </Container>
        );

    }

}

