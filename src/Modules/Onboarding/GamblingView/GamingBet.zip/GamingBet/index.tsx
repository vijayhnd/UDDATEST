import G_GamingBetView from "./GamingBet";

export default G_GamingBetView;