import G_ContestDashboardView from './ContestDashboardView';

export default G_ContestDashboardView;