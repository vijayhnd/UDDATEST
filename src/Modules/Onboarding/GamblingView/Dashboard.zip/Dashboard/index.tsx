import G_DashboardView from './DashboardView';

export default G_DashboardView;