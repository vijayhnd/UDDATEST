import G_YourPrivateContest from "./YourPrivateContest";

export default G_YourPrivateContest;