import React, { Component } from "react";
import AppValidationComponent, { AppValidationComponentState, AppValidationComponentProps } from "../../../../Util/AppValidationComponent";
import { View, Text, TouchableWithoutFeedback, TouchableOpacity, Share,  Image, FlatList, ImageBackground,  AsyncStorage,Modal } from "react-native";
import styles from './styles';
import { SafeAreaView } from 'react-navigation';
import Container from '../../../../Components/Container';
import BigButton from '../../../../Components/Button/BigButton';
import GetProfileRequest from "../../../../Services/Profile/GetProfileRequest";
import GetProfileResponseParser from "../../../../Services/Profile/GetProfileResponseParser";
import UpdateProfileResponse from "../../../../Services/Profile/UpdateProfileResponse";
import ServiceKeys from "../../../../Services/Core/ServiceKeys";
import LongButton from '../../../../Components/Button/LongButton';
import AlertUtil from "../../../../Util/AlertUtil";
import Application from "../../../../Entities/Application";
import RouterBuilder from "../../../../Router";
import AppScreens from "../../../../Util/AppScreens";
import ServiceAction from "../../../../ReduxStore/Generic/GenericeServiceAction";
import { connect } from 'react-redux';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { ISubheaderListener } from "../../../../Components/CustomComponents/SubHeader/SubHeader";
import { MenuIconListener } from "../../../../Components/Icons/MenuIcon/MenuIcon";
import { ServiceType } from "../../../../Services/Core/ServiceFactory";
import { ServiceRequestStatus } from "../../../../ReduxStore/ServiceState";
import { GlobalAppState } from "../../../../ReduxStore";
import { UDDAError } from "../../../../Entities";
import GetProfileResponse from "../../../../Services/Profile/GetProfileResponse";
import { Dialog } from 'react-native-simple-dialogs';
import moment from 'moment';
import LogoutUtill from "../../../../Util/LogoutUtill";
import UrlService from '../../../../Services/Core/ServiceURI'

import ReferralService from "../../../../Services/Referral/ReferralService";

const ProfilePageContent = {
    key: 'somethun',
    page_title: 'PROFILE',
    change_photo: 'Change Photo',
    username_placeholder: 'EMAIL ADDRESS',
    firstName_placeholder: 'FIRST NAME',
    lastName_placeholder: 'LAST NAME',
    email_placeholder: 'EMAIL ADDRESS',
    mobile_placeholder: 'MOBILE NUMBER',
    save_changes_button: 'Save Changes',
    settings: {
        shipping_address: 'Shipping Address',
        social_media_accounts: 'Social Media Accounts',
        my_wallet: 'My Wallet',
        my_bets: 'My Bets',
        transaction_history: 'Transaction History',
        terms_of_use: 'Terms of Use',
        privacy_policy: 'Privacy Policy',
        private_bet_messeges: 'Private Bet Messeges'
    },
    log_out_button: 'LOG OUT',
    profile_save_success_message: 'Profile successfully saved',
    page: 1
}

interface G_YourPrivateContestProp extends AppValidationComponentProps {
    updateProfileRequestStatus?: ServiceRequestStatus
    updateProfileResponse?: UpdateProfileResponse
    updateProfileError?: UDDAError
    getProfileRequestStatus?: ServiceRequestStatus
    getProfileResponse?: GetProfileResponse
    getProfileError?: UDDAError
    serviceKey?: string
    listeners?: any
}

interface ProflieViewState extends AppValidationComponentState {
    contentInsetBottom?: any
    dialogVisible: boolean,
    OrderSummaryDialog: boolean,
    AcceptedContests: any,
    private_contest_array: any,
    Subscribed: any,
    JoinNowSelected: any,
    loader: any;
    SelectedContest: any;
    Dialog: boolean;
    shareDialog: any;
    Share_Show_Msg: any;
    MessageUrl: any;
    MessageString: any;
    CreatedContest:any;
    imagezoom:any;
    OpenPlaySwitchAccepted:any;

}



const bottom_initial = 0;

export class G_YourPrivateContest extends AppValidationComponent<G_YourPrivateContestProp, ProflieViewState>
    implements MenuIconListener, ISubheaderListener {

    private serviceRequestInProgress = false
    private authorisationToken = Application.sharedApplication().user!.authenticationToken;
    private Username = Application.sharedApplication().user!.profile.firstName + " " + Application.sharedApplication().user!.profile.lastName;
    private referralservice = new ReferralService();

    constructor(props: G_YourPrivateContestProp) {
        super(props);
        this.state = {
            contentInsetBottom: bottom_initial,
            dialogVisible: false,
            OrderSummaryDialog: false,
            AcceptedContests: '',
            private_contest_array: '',
            Subscribed: '',
            JoinNowSelected: '',
            Dialog: false,
            loader: false,
            SelectedContest: '',
            shareDialog: false,
            imagezoom: false,
            Share_Show_Msg: '',
            MessageUrl: '',
            MessageString: '',
            CreatedContest:'A',
            OpenPlaySwitchAccepted:true,
        }
    }



    async saveoverlay(){
        try {
          await AsyncStorage.setItem('privatecontestoverlay', 'true');
          this.setState({imagezoom:false})
        } catch (error) {
          // Error retrieving data
          console.log(error.message);
        }
      }
      async closecurrent(){
        
        this.setState({imagezoom:false})
        try {
          await AsyncStorage.setItem('privatecontestoverlaycurrent', 'true');
         
        } catch (error) {
          // Error retrieving data
          console.log(error.message);
        }
      }
   async componentDidMount() {

        let userId = '';
        let current = '';
        var that = this;
        try {
            current = await AsyncStorage.getItem('privatecontestoverlaycurrent');
          userId = await AsyncStorage.getItem('privatecontestoverlay');
          
          console.log('privatecontestoverlay response',userId)
          if(userId == 'true')
          {
            this.setState({imagezoom:false})
          }else{

            if(current == 'true')
            { setTimeout(function(){
                 that.setState({imagezoom:false})
               },1000)
             }else{
                 setTimeout(function(){
                     that.setState({imagezoom:true})
                   },1000)
             }
          }
        } catch (error) {
          // Error retrieving data
          console.log(error.message);
        }


        this.callMethod();
        this.callAcceptedContest();

    }







// -------------------------------------------------- API Calling ------------------------------------------------------
    callMethod() {
        
        this.setState({ loader: true }); 
        fetch(UrlService.CONSTURI +'index.php/'+ UrlService.APIVERSION3 +'/apiGaming/get_private_contest_of_user', {
        // fetch(UrlService.CONSTURI +'index.php/'+ UrlService.APIVERSION3 +'/Custom_SquareGaming/get_private_contest_of_user', {
            method: 'GET',
            headers: {
                'Content-Type': 'multipart/form-data',
                'authorisation': this.authorisationToken
            },
        }).then((response) => response.json())
            .then((responseJson) => {
                this.setState({ loader: false }); 
                console.log('get_private_contest_of_user ' + JSON.stringify(responseJson));
                if ( responseJson.message == 'success') {
                    this.setState({ private_contest_array: responseJson.data.private_contest_array });
                }
                else {
                    this.setState({ private_contest_array: [] });
                }
                if (responseJson.message == "Access Expired.") {
                    // AlertUtil.show("Session Expired ! Please login again");
                    console.log("Footer comp ---->"+responseJson.message);
                    LogoutUtill.logoutButtonPressed(this.props);
                   }
            })
            .catch(error => {
                this.setState({ loader: false }); 
                AlertUtil.show("Error " + JSON.stringify(error));
                console.log(error);
            }) 
    }

    callAcceptedContest() {
        

        fetch(UrlService.CONSTURI +'index.php/'+ UrlService.APIVERSION3 +'/apiGaming/get_accepted_private_contest', {
        // fetch(UrlService.CONSTURI +'index.php/'+ UrlService.APIVERSION3 +'/Custom_SquareGaming/get_accepted_private_contest', {
            method: 'GET',
            headers: {
                'Content-Type': 'multipart/form-data',
                'authorisation': this.authorisationToken
            },
        }).then((response) => response.json())
            .then((responseJson) => {

                console.log('callAcceptedContest ' + JSON.stringify(responseJson));
                if ( responseJson.message == 'success') {
                    this.setState({ AcceptedContests: responseJson.data.accepted_private_contest });
                }
                else {
                    this.setState({ AcceptedContests: [] });

                }
                if (responseJson.message == "Access Expired.") {
                    // AlertUtil.show("Session Expired ! Please login again");
                    console.log("Footer comp ---->"+responseJson.message);
                    LogoutUtill.logoutButtonPressed(this.props);
                   }
            })
            .catch(error => {
                AlertUtil.show("Error " + JSON.stringify(error));
                console.log(error);
            }) 
    }






// -------------------------------------------------------- Methods ------------------------------------------------------


    iconDidTapped() {
        this.props.navigation!.navigate(AppScreens.G_Settings_2_View);
    }

    LogoiconDidTapped() {
        RouterBuilder.replaceRouteTo(AppScreens.G_DashboardView, this.props)
    }

    accountNameTapped() {
        RouterBuilder.replaceRouteTo(AppScreens.G_ProfileView, this.props)
    }

    openPlaysTapped() {
        RouterBuilder.replaceRouteTo(AppScreens.G_UddaContests, this.props)
    }

    coveredPlaysTapped() {
        RouterBuilder.replaceRouteTo(AppScreens.G_GamingBetView, this.props)
    }

    availableBalanceTapped() {

    }

    logoutButtonPressed() {
        Application.sharedApplication().logout()
        RouterBuilder.resetRouteTo(AppScreens.OnboardingStack, this.props)
    }

    gotDetailsScreen(item: any) {
        AsyncStorage.multiSet([
            ["Selected_contest", item.private_contest_id]
        ])
        RouterBuilder.replaceRouteTo(AppScreens.G_PrivateContestUserView, this.props)
    }

    gotocontestDashboard(selected_item: any) {
        AsyncStorage.multiSet([
            ["league_id", selected_item.league_id],
            ["contest_id", selected_item.private_contest_id],
            ["private_contest_id", selected_item.private_contest_id],
            ["from_private_contest", "1"],
        ])
        RouterBuilder.replaceRouteTo(AppScreens.G_ContestDashboardView, this.props);
    }


    gotoSquarecontestDashboard(selected_item: any) {
        // AsyncStorage.multiSet([
        //     ["league_id", selected_item.league_id],
        //     ["contest_id", selected_item.private_contest_id],
        //     ["private_contest_id", selected_item.private_contest_id],
        //     ["from_private_contest", "1"],
        // ])
      //  RouterBuilder.replaceRouteTo(AppScreens.G_ContestDashboardView, {bet_id:selected_item});
      this.props.navigation!.replace(AppScreens.G_ContestviewSquare,{params:{bet_id:selected_item.encryptor_square_id}})
    }

    settleCustomPool(item: any, result_status:any) {
        this.props.navigation!.replace(AppScreens.G_SettlePoolInfoView, { item: item, result_status: result_status});
    }
    aggreeDisagrePage(item: any,result_status:any) {
       
            this.props.navigation!.replace(AppScreens.G_AgreeDisagreeInfoView, { item: item, result_status: result_status })
    
      
    }


    SharePrivateContest(item: any) {

        var MessageString: any;
        var ShowString: any;
        var url: any;

        url = "http://bet.udda.com/index.php?t=contestbet&i=" + item.encryptor_private_contest_id;

        MessageString = "You have been invited to a private contest through UDDA by " + this.Username + ". Open Link : " + url;


        ShowString = <Text style={{ fontFamily: 'Montserrat-Regular', fontSize: hp(1.4), }}>
            You have been invited to a private contest through UDDA by <Text style={{ fontFamily: 'Montserrat-SemiBold' }}> {this.Username} </Text>
        </Text>


        this.setState({ MessageString: MessageString });
        this.setState({ Share_Show_Msg: ShowString });
        this.setState({ MessageUrl: url });
        console.log("Private Contest " + JSON.stringify(MessageString));
        this.setState({ shareDialog: true });
    }



    shareNow() {
        var Message = this.state.MessageString;
        Share.share({
            message: Message
        }).then((result: any) => {
            this.setState({ shareDialog: false })
            console.log('share result' + JSON.stringify(result));
        }).catch((errorMsg: any) => {
            this.setState({ shareDialog: false })
            console.log('share error ' + JSON.stringify(errorMsg));
        });
    }

    CreatedContestMethode(C_Type: any) {

        this.setState({ CreatedContest: C_Type });
        if(C_Type=='A'){
            this.referralservice.logEvent('AcceptedContest_Click', {});
        }else{
            this.referralservice.logEvent('CreatedContest_Click', {});
        }

    }

  
// --------------------------------------------------- Design and Design Methods ------------------------------------------------------

    render() {
        return (
            <Container title={ProfilePageContent.page_title}
                isHeader={true}
                isSubHeader={true}
                isTitle={false}
                showIndicator={this.serviceRequestInProgress}
                menuIconListener={this}
                LogoIconListener={this}
                accountNameListener={this}
                availableBalanceListener={this}
                openPlaysListener={this}
                coveredPlaysListener={this}
                isSetting={false}>

                    {UrlService.OVERLAY==0? this.state.CreatedContest == 'C'?<Modal visible={this.state.imagezoom} transparent={true}>
         <View style={{height:'100%', width:'100%',flex:1}}>
             <SafeAreaView forceInset={{bottom:'never'}}>
         <ImageBackground source={require('../../../../images/your-private-bet-overlay.png')}
                                resizeMode="stretch"
                                style={{ width: '100%', height: '100%' }}>
                                  <View  style={{  position: 'absolute',  justifyContent: 'center', bottom: '2%' ,width:'100%',alignContent:'center',alignItems:'center'}}>
                                <View style={{width:'90%',justifyContent:'space-between',flexDirection:'row'}}>
                                <Text 
                                  style={{marginTop:15,fontFamily: 'Montserrat-Bold', fontSize: hp(2.0), textDecorationLine:  'underline',color:'#68bcbc'}}
                                   onPress={()=>{this.saveoverlay()}}
                                   >Don't show again</Text>

<TouchableWithoutFeedback  onPress={()=>this.closecurrent()}>
                       <Image source={require('../../../../images/close_overlay.png')}  style={{height:50,width:50 }}></Image>
                       </TouchableWithoutFeedback>

                                </View>
                                  </View>

                                </ImageBackground>
                                </SafeAreaView>
         </View>
          
        </Modal>:null:null}
         
                {/* -------------------------------- Share Dialogue --------------------------------*/}
                <Dialog
                    visible={this.state.shareDialog}
                    title=""
                    onTouchOutside={() => this.setState({ shareDialog: false })} >

                    <View style={{ backgroundColor: "white" }}>

                        <View style={{ justifyContent: "center" }} >

                            <View style={{ flexDirection: 'row' }}>
                                <View style={{ width: '85%', paddingLeft: '15%' }}>
                                    <Image source={require('../../../../images/udda_logo_white.png')} style={{ width: wp(30), height: wp(7), margin: 10, alignSelf: 'center' }} resizeMode='contain' />
                                </View>
                                <View style={{ width: '15%' }}>
                                    <TouchableWithoutFeedback onPress={() => { this.setState({ shareDialog: false }) }}>
                                        <View>
                                            <Image source={require('../../../../images/close.png')} style={{ height: 13, width: 13, alignSelf: 'flex-end', marginRight: 8, marginTop: 10 }}></Image>
                                        </View>
                                    </TouchableWithoutFeedback>
                                </View>
                            </View>


                            <View style={{ width: '100%', backgroundColor: '#cccccc', height: 1, marginTop: 1, padding: 0 }}></View>

                            <View style={{ justifyContent: "center", padding: 10 }}>

                                <Text style={{ padding: 1, fontFamily: 'Montserrat-SemiBold', fontSize: hp(1.7), marginTop: 3, color: 'black' }}>Messege</Text>

                                <View style={{ padding: 1, borderColor: '#cccccc', borderWidth: 1, marginTop: 5, }}>
                                    <Text style={{ padding: 8, width: '100%', height: 'auto' }}>{this.state.Share_Show_Msg}</Text>

                                </View>
                                <Text style={{ padding: 1, fontFamily: 'Montserrat-Regular', fontSize: hp(1.5), marginTop: 5, color: 'black' }}>
                                    {this.state.MessageUrl}
                                </Text>
                                <BigButton title="Share Now" style={styles.verify_button} textStyle={styles.verify_button_text_style}
                                    listener={() => { this.shareNow() }} />
                               
                            </View>
                        </View>
                    </View>
                </Dialog>


             

                <View style={{ width: '100%', height: '100%'}}>

                <View style={{height:hp(8),width:'100%',backgroundColor:'white',flexDirection:'row',justifyContent:'space-between',padding:10}}>
                        <View style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                        <Text style={styles.NameStyle}>CONTESTS</Text>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <View style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Text style={{ fontSize: hp(1.5), fontFamily: 'Montserrat-SemiBold', marginLeft: 5, marginRight: 2, color: this.state.OpenPlaySwitchAccepted == false ? 'black' : '#888888', textAlign: 'right'}}>Public</Text>
                                <Text style={{ fontSize: hp(1.5), fontFamily: 'Montserrat-SemiBold', marginLeft: 5, marginRight: 2, color: this.state.OpenPlaySwitchAccepted == false ? 'black' : '#888888', textAlign: 'right'}}>Contests</Text>
                            </View>
                            <View style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                            <TouchableWithoutFeedback onPress={() => { this.setState({OpenPlaySwitchAccepted:!this.state.OpenPlaySwitchAccepted}) }}>
                                            <Image source={this.state.OpenPlaySwitchAccepted == true ? require('../../../../images/toggle_on_G.png') : require('../../../../images/toggle_off.png')}
                                                style={{ height: 20, width: 40 }}
                                                resizeMode="contain"></Image>
                                        </TouchableWithoutFeedback>
                            </View>
                            <View style={{justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                <Text style={{ fontSize: hp(1.5), fontFamily: 'Montserrat-SemiBold', marginLeft: 5, marginRight: 2, color: this.state.OpenPlaySwitchAccepted == true ? 'black' : '#888888', textAlign: 'left' }}>Private</Text>
                                <Text style={{ fontSize: hp(1.5), fontFamily: 'Montserrat-SemiBold', marginLeft: 5, marginRight: 2, color: this.state.OpenPlaySwitchAccepted == true ? 'black' : '#888888', textAlign: 'left' }}>Contests</Text>
                            </View>
                        </View>
                    </View>

                    {/* <View style={{ width: '100%', marginTop: 15, marginBottom: 15, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={{ color: '#68bcbc', fontFamily: 'Montserrat-Bold', fontSize: 14 }} >YOUR PRIVATE CONTESTS</Text>
                    </View> */}
                    <View style={styles.mainContent}>
                        <View style={{ width: '100%' }}>
                            <View style={{ width: '100%' ,justifyContent:'center',alignItems:'center'}}>

                                <View style={{ width: '100%', flexDirection: 'row' }}>
                                    <TouchableOpacity
                                        onPress={() => { this.CreatedContestMethode('A') }}
                                        style={{ width: '50%', backgroundColor: this.state.CreatedContest == 'A' ? '#68bcbc' : '#EEEEEE', padding: 10 }}>
                                        <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                                            <Text style={{ color: this.state.CreatedContest == 'A' ? 'white' : '#999999',fontFamily: 'Montserrat-SemiBold', fontSize: hp(2.0) }}>Accepted Contests</Text>
                                        </View>
                                    </TouchableOpacity>

                                    <TouchableOpacity
                                        onPress={() => { this.CreatedContestMethode('C') }}
                                        style={{ width: '50%', backgroundColor: this.state.CreatedContest == 'C' ? '#68bcbc' : '#EEEEEE', padding: 10 }}>
                                        <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                                            <Text style={{ color: this.state.CreatedContest == 'C' ? 'white' : '#999999',fontFamily: 'Montserrat-SemiBold', fontSize: hp(2.0) }}>Created Contests</Text>
                                        </View>
                                    </TouchableOpacity>
                                </View>

                                {this.state.CreatedContest == 'A' ?
                                    <View style={{ width: '95%',height:'95%' }}>
                                        {this.state.AcceptedContests.length > 0 ?
                                            <View>
                                                <FlatList
                                                    data={this.state.AcceptedContests}
                                                    extraData={this.state}
                                                    keyExtractor={(item: any, index: any) => index.toString()}
                                                    renderItem={({ item, index }: any) => {
                                                        var subindex = index;
                                                        var new_ContestStartTimestamp = item.contest_start_date_timestamp * 1000;
                                                      //garima  var new_ContestStartDate = moment(new_ContestStartTimestamp).subtract(1, 'days').format('Do MMM'); 
                                                        var new_ContestStartDate = moment(new_ContestStartTimestamp).format('Do MMM');
 
                                                        return (
                                                            <View style={{ width: '100%',padding:10 }}>
                                                                <ImageBackground source={require('../../../../images/UddaContestsYellow.png')}
                                                                    resizeMode="stretch"
                                                                    style={{ width: '100%', height: 60, marginTop: 10 }}>
                                                                    <View style={{ width: '100%', flexDirection: 'row' }}>
                                                                        <TouchableWithoutFeedback onPress={() => { (item.ttype == 'square' || item.ttype == 'pool')? null:this.gotDetailsScreen(item) }  }>
                                                                            <View style={{ width: '60%', height: 60, justifyContent: 'center', paddingLeft: 10, }}>
                                                                                <Text style={styles.Challenge_Name_Text}>
                                                                                    {item.ttype == 'square' ? item.game_name : item.ttype == 'pool' ? item.pool_name:item.contest_name}
                                                                                </Text>
                                                                                <Text style={[styles.Challenge_Name_Text, { fontFamily: 'Montserrat-SemiBold', fontSize: 11 }]}>
                                                                                    by {item.creator}
                                                                                </Text>
                                                                                {/*garima */}
                                                                                {item.ttype=='square'?<Text style={styles.Registration_Text}>
                                                                               { moment(item.game_start_timestamp * 1000).format('LT') +' '+ new Date(item.game_start_timestamp * 1000).toString().split(' ')[6].toString().substr(1, new Date(item.game_start_timestamp * 1000).toString().split(' ')[6].length - 2) +' '+ moment(item.game_start_timestamp * 1000).format('LL')}
                                                                                </Text> : item.ttype == 'pool' ? <Text style={styles.Registration_Text}>
                                                                                        {moment(item.expired_timestamp * 1000).format('LT') + ' ' + new Date(item.expired_timestamp * 1000).toString().split(' ')[6].toString().substr(1, new Date(item.expired_timestamp * 1000).toString().split(' ')[6].length - 2) + ' ' + moment(item.expired_timestamp * 1000).format('LL')}
                                                                                </Text>:<Text style={styles.Registration_Text}>
                                                                                Registration closes on {item.contest_end_date}
                                                                            </Text>}
                                                                            </View>
                                                                        </TouchableWithoutFeedback>
                                                                        <View style={{ width: '40%', height: 60, justifyContent: 'center', paddingRight: 5, }}>
                                                                            {item.ttype=='square'?<View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                                                            <Image
                                                                                resizeMode="contain"
                                                                                style={{ height: hp(1.3), width: hp(1.5) }}
                                                                                source={{ uri:item.sport_icon}}></Image>
                                                                                <Text style={styles.Joining_Text}>&nbsp;Football Squares</Text>                                                                      
                                                                            </View> : item.ttype == 'pool' ? <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                                                                 <Image
                                                                                    resizeMode="contain"
                                                                                    style={{ height: hp(1.3), width: hp(1.5) }}
                                                                                    source={{ uri: item.sport_icon }}></Image> 
                                                                                    <Text style={styles.Joining_Text}>&nbsp;Custom Pool</Text>
                                                                            </View> :
                                                                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                                                                <Text style={styles.Joining_Text}>Joining Fee.</Text>
                                                                                <Image
                                                                                    resizeMode="contain"
                                                                                    style={{ height: hp(1.3), width: hp(1.5) }}
                                                                                    source={require('../../../../images/Buckscut.png')}></Image>
                                                                                <Text style={styles.Joining_Price}>
                                                                                    {item.join_fee}.
                                                                    <Text style={{ color: 'black', fontFamily: 'Montserrat-Bold', fontSize: 8 }}>00</Text>
                                                                                </Text>
                                                                            </View>}
                                                                            {(item.ttype == 'pool' && item.result_status=='FINAL')?
                                                                                <TouchableOpacity onPress={() => { item.ttype == 'pool' && item.result_status == 'FINAL' && item.action != null ? this.settleCustomPool(item, 1) : this.aggreeDisagrePage(item,1)  }}>
                                                                                    <View style={{ backgroundColor: '#ff9900', justifyContent: 'center' }}>
                                                                                    <Text style={styles.Join_Now_Text}>View</Text>
                                                                                    </View>
                                                                                </TouchableOpacity>
                                                                                : <TouchableOpacity onPress={() => { (item.ttype == 'pool' && item.result_status == '') ? this.aggreeDisagrePage(item, 0):(item.ttype == 'square' ? this.gotoSquarecontestDashboard(item) : this.gotocontestDashboard(item) )}}>
                                                                                    <View style={{ backgroundColor: '#ff9900', justifyContent: 'center' }}>
                                                                                        <Text style={styles.Join_Now_Text}>View</Text>
                                                                                    </View>
                                                                                </TouchableOpacity>

                                                                            }
                                                                            
                                                                        </View>
                                                                    </View>
                                                                </ImageBackground>
                                                            </View>
                                                        )
                                                    }} />
                                            </View>
                                            :
                                            <View style={{ justifyContent: 'center', alignItems: 'center', paddingVertical: 20 }}>
                                                <Text style={{ color: 'white', fontFamily: 'Montserrat-SemiBold', fontSize: 14,textAlign:'center'  }}>You have not accepted any contests yet</Text>
                                            </View>
                                        }

                                    </View>
                                    : null}


                                {this.state.CreatedContest == 'C' ?
                                    <View style={{ width: '95%',height:'95%'}}>

                                        {this.state.private_contest_array.length > 0 ?

                                            <FlatList
                                                data={this.state.private_contest_array}
                                                extraData={this.state}
                                                keyExtractor={(item: any, index: any) => index.toString()}
                                                renderItem={({ item, index }: any) => {
                                                    var subindex = index;
                                                    var new_ContestStartTimestamp = item.contest_start_date_timestamp * 1000;
                                                   // var new_ContestStartDate = moment(new_ContestStartTimestamp).subtract(1, 'days').format('Do MMM'); //garima
                                                   var new_ContestStartDate = moment(new_ContestStartTimestamp).format('Do MMM'); 
                                                    return (
                                                        <View style={{ width: '100%',padding:10 }}>

                                                            <ImageBackground source={require('../../../../images/UddaContestsGreen.png')}
                                                                resizeMode="stretch"
                                                                style={{ width: '100%', height: 60 }}>
                                                                <View style={{ width: '100%', flexDirection: 'row' }}>
                                                                    <TouchableWithoutFeedback onPress={() => { item.ttype == 'contest' && this.gotDetailsScreen(item) }}>
                                                                        <View style={{ width: '60%', height: 60, justifyContent: 'center', paddingLeft: 10, }}>
                                                                            <Text style={styles.Month_Text}>
                                                                                {item.ttype == 'square' ? item.game_name : item.ttype == 'pool' ? item.pool_name : item.contest_name}

                                                                            </Text>
                                                                            {/*garima*/}
                                                                            {item.ttype=='square'?<Text style={styles.Registration_Text}>
                                                                               { moment(item.game_start_timestamp * 1000).format('LT') +' '+ new Date(item.game_start_timestamp * 1000).toString().split(' ')[6].toString().substr(1, new Date(item.game_start_timestamp * 1000).toString().split(' ')[6].length - 2) +' '+ moment(item.game_start_timestamp * 1000).format('LL')}
                                                                            </Text> : item.ttype == 'pool' ? <Text style={styles.Registration_Text}>
                                                                                {moment(item.expired_timestamp * 1000).format('LT') + ' ' + new Date(item.expired_timestamp * 1000).toString().split(' ')[6].toString().substr(1, new Date(item.expired_timestamp * 1000).toString().split(' ')[6].length - 2) + ' ' + moment(item.expired_timestamp * 1000).format('LL')}
                                                                            </Text>:<Text style={styles.Registration_Text}>
                                                                                Registration closes on {item.contest_end_date}
                                                                            </Text>}
                                                                        </View>
                                                                    </TouchableWithoutFeedback>
                                                                    <View style={{ width: '40%', height: 60, justifyContent: 'center', paddingRight: 5, }}>
                                                                       { item.ttype=='square'?<View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                                                       <Image
                                                                                resizeMode="contain"
                                                                                style={{ height: hp(1.3), width: hp(1.5) }}
                                                                                source={{ uri:item.sport_icon}}></Image>
                                                                            <Text style={styles.Joining_Text}> &nbsp;Football Squares</Text>                                                                            
                                                                        </View> : item.ttype == 'pool' ? <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                                                            <Image
                                                                                resizeMode="contain"
                                                                                style={{ height: hp(1.3), width: hp(1.5) }}
                                                                                source={{ uri: item.sport_icon }}></Image>
                                                                            <Text style={styles.Joining_Text}>&nbsp;Custom Pool</Text>
                                                                        </View>:<View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                                                            <Text style={styles.Joining_Text}>Joining Fee.</Text>
                                                                            <Image
                                                                                resizeMode="contain"
                                                                                style={{ height: hp(1.3), width: hp(1.5) }}
                                                                                source={require('../../../../images/Buckscut.png')}></Image>
                                                                            <Text style={styles.Joining_Price}>
                                                                                {item.join_fee}.
                                                                                <Text style={{ color: 'black', fontFamily: 'Montserrat-Bold', fontSize: 8 }}>00</Text>
                                                                            </Text>
                                                                        </View>}
                                                                        {(item.ttype == 'pool' && item.result_status == 'FINAL') ?
                                                                            <TouchableOpacity onPress={() => { item.ttype == 'pool' ? this.settleCustomPool(item,1) : '' }}>
                                                                                <View style={{ backgroundColor: '#68bcbc', justifyContent: 'center' }}>
                                                                                    <Text style={styles.Join_Now_Text}>View</Text>
                                                                                </View>
                                                                            </TouchableOpacity>
                                                                            : <TouchableOpacity onPress={() => { item.ttype == 'square' ? this.gotoSquarecontestDashboard(item) : (item.ttype == 'pool' && item.result_status == '') ?this.settleCustomPool(item,0): this.gotocontestDashboard(item) }}>
                                                                                <View style={{ backgroundColor: '#68bcbc', justifyContent: 'center' }}>
                                                                                    <Text style={styles.Join_Now_Text}>View</Text>
                                                                                </View>
                                                                            </TouchableOpacity>

                                                                        }
                                                                        
                                                                    </View>


                                                                </View>
                                                            </ImageBackground>
                                                        </View>


                                                    )
                                                }}
                                            />
                                            :
                                            <View style={{ justifyContent: 'center', alignItems: 'center', paddingVertical: 20 }}>
                                                <Text style={{ color: 'white', fontFamily: 'Montserrat-SemiBold', fontSize: 14,textAlign:'center' }}> You have not created any private contests yet</Text>
                                            </View>
                                        }
                                    </View>
                                    : null}

                                    
                            </View>
                        </View>
                    </View>
             
                </View>
            </Container >
        );
    }

}

const mapStateToProps = (state: GlobalAppState) => ({
    requestStatus: state.serviceReducer.requestStatus,
    error: state.serviceReducer.error,
    updateProfileRequestStatus: state.serviceReducer.requestStatus,
    updateProfileResponse: state.serviceReducer.response,
    updateProfileError: state.serviceReducer.error,
    getProfileRequestStatus: state.serviceReducer.requestStatus,
    getProfileResponse: state.serviceReducer.response,
    getProfileError: state.serviceReducer.error,
    serviceKey: state.serviceReducer.serviceKey,
    listeners: state.serviceReducer.listeners
})

export default connect(mapStateToProps)(G_YourPrivateContest);