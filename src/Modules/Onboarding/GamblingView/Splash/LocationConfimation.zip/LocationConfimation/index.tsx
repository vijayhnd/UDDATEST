import G_LocationConfirmation from "./LocationConfirmation";

export default G_LocationConfirmation